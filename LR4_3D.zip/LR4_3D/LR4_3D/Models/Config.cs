﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR3_3D.Models
{
    internal class Config
    {
        public class AppConfig
        {
            public string DepthMapFileName { get; set; } = "DepthMap_11.dat";
            public LightingConfig Lighting { get; set; } = new();
            public CameraConfig Camera { get; set; } = new();
            public RenderConfig Render { get; set; } = new();
            public ExportConfig Export { get; set; } = new();
        }

        public class LightingConfig
        {
            public string Model { get; set; } = "Phong"; // "Lambert", "Phong", "OrenNayar"
            public float[] LightDirection { get; set; } = new[] { 1.0f, 1.0f, 1.0f };
            public float[] LightColor { get; set; } = new[] { 1.0f, 1.0f, 1.0f };
            public float Intensity { get; set; } = 1.0f;
            public float Roughness { get; set; } = 0.5f; // Для Oren-Nayar
        }

        public class CameraConfig
        {
            public float[] Position { get; set; } = new[] { 0f, 0f, 600f };
            public float Yaw { get; set; } = 90.0f;
            public float Pitch { get; set; } = 0.0f;
            public float Zoom { get; set; } = 600.0f;
            public float FOV { get; set; } = 45.0f;
        }

        public class RenderConfig
        {
            public bool RenderToBmp { get; set; } = true;
            public string BmpOutputName { get; set; } = "output.bmp";
            public int BmpWidth { get; set; } = 1280;
            public int BmpHeight { get; set; } = 720;
        }

        public class ExportConfig
        {
            public string FormatToExport { get; set; } = "stl";
            public string OutputName { get; set; } = "output2";
        }
    }
}
