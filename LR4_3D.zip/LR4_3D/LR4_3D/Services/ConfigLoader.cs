﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static LR3_3D.Models.Config;

namespace LR3_3D.Services
{
    internal class ConfigLoader
    {
        public static AppConfig Load(string path = "config.json")
        {
            if (!File.Exists(path))
            {
                var defaultConfig = new AppConfig();
                Save(defaultConfig, path);
                return defaultConfig;
            }

            var json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<AppConfig>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                WriteIndented = true
            }) ?? new AppConfig();
        }

        public static void Save(AppConfig config, string path = "config.json")
        {
            var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(path, json);
        }
    }
}
