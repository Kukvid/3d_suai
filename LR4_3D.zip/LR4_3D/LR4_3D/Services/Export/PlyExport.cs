﻿using LR3_3D.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR3_3D.Services.Export
{
    public class PlyExporter : IExporter
    {
        public string FileExtension => "ply";
        public string FilterString => "PLY Files (*.ply)|*.ply";

        public void ExportToFile(Mesh mesh, string fileName)
        {
            using var fileStream = new FileStream(fileName + "." + FileExtension, FileMode.Create);
            ExportToStream(mesh, fileStream);
        }

        public void ExportToStream(Mesh mesh, Stream stream)
        {
            using var writer = new StreamWriter(stream, Encoding.ASCII);

            writer.WriteLine("ply");
            writer.WriteLine("format ascii 1.0");
            writer.WriteLine($"element vertex {mesh.VertexCount}");
            writer.WriteLine("property float x");
            writer.WriteLine("property float y");
            writer.WriteLine("property float z");
            writer.WriteLine("property float nx");
            writer.WriteLine("property float ny");
            writer.WriteLine("property float nz");
            writer.WriteLine($"element face {mesh.TriangleCount}");
            writer.WriteLine("property list uchar int vertex_indices");
            writer.WriteLine("end_header");

            // Вершины (x y z nx ny nz)
            foreach (var vertex in mesh.Vertices)
            {
                writer.WriteLine($"{Format(vertex.Position.X)} {Format(vertex.Position.Y)} {Format(vertex.Position.Z)} " +
                               $"{Format(vertex.Normal.X)} {Format(vertex.Normal.Y)} {Format(vertex.Normal.Z)}");
            }

            // Грани (3 v1 v2 v3)
            for (int i = 0; i < mesh.Indices.Count; i += 3)
            {
                writer.WriteLine($"3 {mesh.Indices[i]} {mesh.Indices[i + 1]} {mesh.Indices[i + 2]}");
            }
        }

        private string Format(float value)
        {
            return value.ToString("G6", CultureInfo.InvariantCulture);
        }
    }

}
