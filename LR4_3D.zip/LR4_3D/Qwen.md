# LR3_3D - 3D Surface Visualization Application

## Overview

LR3_3D is a 3D visualization application built with C# and OpenGL using the OpenTK library. The application specializes in converting depth map data files into 3D surfaces and rendering them in real-time. It supports loading depth maps from binary `.dat` files and can export the generated 3D meshes to STL format.

## Project Structure

```
LR3_3D/
├── Program.cs                # Entry point and main application setup
├── MainWindow.cs             # Main 3D rendering window and game loop
├── Models/
│   ├── DepthMap.cs           # Represents a 2D depth map with width, height, and data
│   ├── Mesh.cs               # Defines mesh structure with vertices and indices
│   └── Vertex.cs             # Vertex structure with position, normal, and color
├── Rendering/
│   ├── ShaderProgram.cs      # Manages OpenGL shader programs
│   ├── MeshRenderer.cs       # Handles rendering of meshes
│   ├── VAO.cs                # Vertex Array Object wrapper
│   ├── VBO.cs                # Vertex Buffer Object wrapper
│   └── EBO.cs                # Element Buffer Object wrapper
├── Services/
│   ├── DataLoaders/          # Classes for loading different data types
│   │   ├── DepthMapLoader.cs
│   │   ├── DataLoaderFactory.cs
│   │   └── IDataLoader.cs
│   ├── Export/               # Export functionality for different formats
│   │   ├── StlExporter.cs
│   │   └── IExporter.cs
│   └── MeshGenerators/       # Converters from input data to 3D meshes
│       ├── DepthMapStlMeshGenerator.cs
│       └── IMeshGenerator.cs
└── LR3_3D.csproj            # Project configuration and dependencies
```

## Key Features

### 1. Depth Map Visualization
- Loads binary depth map files (`.dat`)
- Converts depth maps into 3D triangular meshes
- Real-time rendering of 3D surfaces

### 2. Interactive Controls
- Camera rotation with mouse look (yaw/pitch)
- Zoom controls
- Perspective projection with adjustable FOV
- First-person navigation controls

### 3. Export Functionality
- Export 3D meshes to STL format
- Support for multiple export formats (extensible architecture)

### 4. Rendering Pipeline
- Programmable OpenGL pipeline with custom shaders
- Phong lighting model with configurable light source
- Depth testing and face culling
- Anti-aliasing support

## Technical Architecture

### Data Flow
1. **Loading**: Binary depth map files are loaded via `DepthMapLoader`
2. **Processing**: Depth map data is converted to 3D mesh using `DepthMapStlMeshGenerator`
3. **Rendering**: Mesh is rendered using OpenGL with custom shaders
4. **Export**: Generated meshes can be exported to various formats

### Core Technologies
- **Language**: C# (.NET 8.0)
- **Graphics Library**: OpenTK 4.9.4 (OpenGL 4.x)
- **Windowing**: OpenTK Windowing Desktop
- **UI Framework**: Windows Forms
- **Dependencies**: 
  - OpenTK
  - OpenTK.Windowing.Desktop
  - System.Drawing.Common

### Input/Output
- **Input**: Binary `.dat` files containing depth map data
- **Output**: STL files for 3D printing/processing

## System Architecture

The application follows a modular architecture with clear separation of concerns:

### Model Layer
- `DepthMap`: Represents a 2D grid of depth values
- `Mesh`: Contains vertex and index data for 3D rendering
- `Vertex`: Vertex structure with position, normal, and color

### Service Layer
- **Data Loaders**: Handle loading different input formats
- **Export**: Support for exporting processed data to various formats
- **Mesh Generators**: Algorithms to convert input data to 3D meshes

### Rendering Layer
- **Shader Management**: Compiles and manages OpenGL shaders
- **Mesh Rendering**: Handles the rendering of 3D geometry
- **OpenGL Wrappers**: Abstractions for VAO, VBO, and EBO objects

## User Interface

### Controls
- **Mouse**: Rotate camera (look around)
- **Scroll Wheel**: Zoom in/out
- **'E' Key**: Export current mesh to file
- **'ESC' Key**: Exit application

### Visual Features
- Perspective camera with adjustable parameters
- Dynamic lighting with configurable light source
- Smooth shading with calculated vertex normals
- Anti-aliased rendering

## Dependencies

The project depends on:
- OpenTK: Cross-platform Graphics and Compute API
- OpenTK.Windowing.Desktop: Desktop windowing for OpenTK
- System.Drawing.Common: Common drawing functionality

## Potential Extensions

1. **Additional Import Formats**: Support for OBJ, PLY, or other 3D formats
2. **More Export Formats**: Add support for OBJ, PLY, or GLTF export
3. **Enhanced Materials**: Support for textures and advanced materials
4. **Animation**: Support for animated sequences or dynamic surfaces
5. **Advanced Lighting**: Multiple lights, shadows, and advanced effects

## Development Notes

The application is built using modern OpenGL practices with programmable shaders. The depth map to 3D mesh conversion algorithm triangulates the depth grid by creating quads from adjacent points and subdividing them into triangles. Normals are calculated per-face and then averaged per vertex for smooth shading.