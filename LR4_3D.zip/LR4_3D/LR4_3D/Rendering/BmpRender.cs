﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using OpenTK.Graphics.OpenGL4;
using System.Runtime.InteropServices;

namespace LR3_3D.Rendering
{
    internal class BmpRender
    {

        public static void RenderToBmp(int width, int height, string outputPath, Action renderAction)
        {
            // Создаём framebuffer
            int fbo = GL.GenFramebuffer();
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, fbo);

            // Создаём текстуру для цвета
            int colorTexture = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, colorTexture);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgb, width, height, 0,
                OpenTK.Graphics.OpenGL4.PixelFormat.Rgb, PixelType.UnsignedByte, IntPtr.Zero);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer, FramebufferAttachment.ColorAttachment0,
                TextureTarget.Texture2D, colorTexture, 0);

            // Создаём renderbuffer для глубины
            int rbo = GL.GenRenderbuffer();
            GL.BindRenderbuffer(RenderbufferTarget.Renderbuffer, rbo);
            GL.RenderbufferStorage(RenderbufferTarget.Renderbuffer, RenderbufferStorage.DepthComponent, width, height);
            GL.FramebufferRenderbuffer(FramebufferTarget.Framebuffer, FramebufferAttachment.DepthAttachment,
                RenderbufferTarget.Renderbuffer, rbo);

            // Проверка
            if (GL.CheckFramebufferStatus(FramebufferTarget.Framebuffer) != FramebufferErrorCode.FramebufferComplete)
                throw new Exception("Framebuffer не готов!");

            // Рендерим
            GL.Viewport(0, 0, width, height);
            renderAction();

            // Читаем пиксели
            byte[] pixels = new byte[width * height * 3];
            GL.ReadPixels(0, 0, width, height, OpenTK.Graphics.OpenGL4.PixelFormat.Rgb, PixelType.UnsignedByte, pixels);

            // Сохраняем в BMP
            using var bitmap = new Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            var bmpData = bitmap.LockBits(new Rectangle(0, 0, width, height),
                ImageLockMode.WriteOnly, bitmap.PixelFormat);

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    int srcIdx = ((height - 1 - y) * width + x) * 3; // OpenGL координаты снизу
                    int dstIdx = (y * width + x) * 3;

                    Marshal.WriteByte(bmpData.Scan0, dstIdx + 2, pixels[srcIdx]);     // R
                    Marshal.WriteByte(bmpData.Scan0, dstIdx + 1, pixels[srcIdx + 1]); // G
                    Marshal.WriteByte(bmpData.Scan0, dstIdx, pixels[srcIdx + 2]);     // B
                }
            }

            bitmap.UnlockBits(bmpData);
            bitmap.Save(outputPath, ImageFormat.Bmp);

            // Очистка
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
            GL.DeleteFramebuffer(fbo);
            GL.DeleteTexture(colorTexture);
            GL.DeleteRenderbuffer(rbo);
        }
    }
}
